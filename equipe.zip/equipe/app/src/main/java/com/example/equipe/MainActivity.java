package com.example.equipe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private static final int splash_screen=3000;

    Animation topAnim , bottomAnim;
    ImageView icon1;
    ImageView  letter;
    ImageView letter1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        topAnim= AnimationUtils.loadAnimation(this,R.anim.top_animation);
        bottomAnim= AnimationUtils.loadAnimation(this,R.anim.bottom_animation);
        icon1=findViewById(R.id.icon1);
        letter=findViewById(R.id.letter);
        letter1=findViewById(R.id.letter1);


        icon1.setAnimation(topAnim);
        letter.setAnimation(bottomAnim);
        letter1.setAnimation(bottomAnim);


        new Handler().postDelayed(new Runnable (){
            @Override
            public void run(){
                Intent intent = new Intent(MainActivity.this,Dashboard.class);
                startActivity(intent);
                finish();
            }
        },splash_screen);
    }
}