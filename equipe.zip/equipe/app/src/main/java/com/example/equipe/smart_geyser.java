package com.example.equipe;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class smart_geyser extends AppCompatActivity {

    TimePicker timePicker,cancelTime;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smart_geyser);
        timePicker = findViewById(R.id.timePicker);
        cancelTime = findViewById(R.id.cancel_time);
        findViewById(R.id.buttonAlarm).setOnClickListener(view -> {
            //We need a calendar object to get the specified time in millis
            //as the alarm manager method takes time in millis to setup the alarm
            Calendar calendar = Calendar.getInstance();
            TimePicker timePicker = findViewById(R.id.timePicker);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH),
                       timePicker.getHour(), timePicker.getMinute(), 0);
            }
            setAlarm(calendar.getTimeInMillis());
        });
        findViewById(R.id.cancelAlarm).setOnClickListener(view -> {
            //We need a calendar object to get the specified time in millis
            //as the alarm manager method takes time in millis to setup the alarm
            Calendar calendar = Calendar.getInstance();
            TimePicker cancelTime = findViewById(R.id.cancel_time);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH),
                        cancelTime.getHour(), cancelTime.getMinute(), 0);
            }
            setAlarm1(calendar.getTimeInMillis());
        });
       
    }
    private void setAlarm(long time) {
        //getting the alarm manager


        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        //creating a new intent specifying the broadcast receiver
        Intent i = new Intent(this, MyAlarm.class);

        //creating a pending intent using the intent
        PendingIntent pi = PendingIntent.getBroadcast(this, 0, i, 0);

        //setting the repeating alarm that will be fired every day

        am.setExact(AlarmManager.RTC_WAKEUP, time, pi);
        Toast.makeText(this, "Alarm is set", Toast.LENGTH_SHORT).show();
    }
    private void setAlarm1(long time) {
        //getting the alarm manager


        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        //creating a new intent specifying the broadcast receiver
        Intent i = new Intent(this, MyAlarm1.class);

        //creating a pending intent using the intent
        PendingIntent pi = PendingIntent.getBroadcast(this, 0, i, 0);

        //setting the repeating alarm that will be fired every day

        am.setExact(AlarmManager.RTC_WAKEUP, time, pi);
        Toast.makeText(this, "Alarm is set to cancel", Toast.LENGTH_SHORT).show();
    }

    }
