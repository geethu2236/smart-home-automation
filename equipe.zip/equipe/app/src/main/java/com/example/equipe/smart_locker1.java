package com.example.equipe;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class smart_locker1 extends AppCompatActivity {
    TextView otp2;
    DatabaseReference databaseReference;
    String status;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smart_locker1);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference("password");
        otp2 = findViewById(R.id.otp2);


        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                status =snapshot.getValue(String.class);
                otp2.setText(status);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }) ;

    }
}