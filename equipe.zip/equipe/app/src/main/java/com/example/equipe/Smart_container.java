package com.example.equipe;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import de.nitri.gauge.Gauge;

public class Smart_container extends AppCompatActivity {

     Gauge gauge;
    TextView smartcontainer;
    DatabaseReference databaseReference;
    String status= "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smart_container);
         gauge = (Gauge) findViewById(R.id.gauge1);
         smartcontainer = (TextView) findViewById(R.id.textView);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference("smart_container");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                status =dataSnapshot.getValue().toString();
                smartcontainer.setText(status);
                gauge.setValue(Float.parseFloat(status));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }
}

