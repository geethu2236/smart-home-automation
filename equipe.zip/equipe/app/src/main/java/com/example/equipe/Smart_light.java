package com.example.equipe;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Smart_light extends AppCompatActivity {
    Button on,off;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smart_light);

        on = findViewById(R.id.butt1);
        off = findViewById(R.id.butt2);
        final  FirebaseDatabase database= FirebaseDatabase.getInstance();

        on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference Power_Supply = database.getReference("Power_Supply");
                Power_Supply.setValue("ON");
            }
        });

        off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference Power_Supply = database.getReference("Power_Supply");
                Power_Supply.setValue("OFF");
            }
        });

    }
}