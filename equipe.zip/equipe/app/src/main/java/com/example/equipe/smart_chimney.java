package com.example.equipe;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class smart_chimney extends AppCompatActivity {


    TextView chimney;
    DatabaseReference databaseReference;
    String status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smart_chimney);


        FirebaseDatabase database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference("chimney");
        chimney = findViewById(R.id.chimney);


        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                status =snapshot.getValue(String.class);
                chimney.setText(status);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }) ;

        };

    }
