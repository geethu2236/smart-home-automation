package com.example.equipe;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class smartfan extends AppCompatActivity {

    Button on,off;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smartfan);
        on = findViewById(R.id.on1);
        off = findViewById(R.id.off1);
        final FirebaseDatabase database= FirebaseDatabase.getInstance();

        on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference Power_Supply = database.getReference("Power_Supply");
                Power_Supply.setValue("ON");
                Toast.makeText(smartfan.this, "dfadsf", Toast.LENGTH_SHORT).show();
            }
        });

        off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference Power_Supply = database.getReference("Power_Supply");
                Power_Supply.setValue("OFF");
            }
        });
    }
}